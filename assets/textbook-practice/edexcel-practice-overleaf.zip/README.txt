Edexcel companion practice - Arij Asad

Six original practice sheets, each with questions first and hints and worked solutions afterwards.

Upload this ZIP into a new Overleaf project. Choose the desired *-practice.tex file as the Main document and compile with pdfLaTeX. You may add PS_logo.png; the source reserves space and compiles without it.

The questions and explanations are original teaching materials. No Pearson textbook pages or third-party SolutionBank PDFs are included.
