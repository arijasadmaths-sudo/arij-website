ALGEBRA TO TMUA - OVERLEAF SOURCE

Original questions and explanations prepared for Arij Asad's teaching resources.

Upload this ZIP to Overleaf and select main.tex as the main document. Compile
with pdfLaTeX. The default output is the two-page student diagnostic.

To choose another document, change the single input line in main.tex to:
  \input{algebra-to-tmua-follow-up.tex}
or
  \input{algebra-to-tmua-teacher-solutions.tex}

Each of the three files is also a complete standalone LaTeX document.
The student and follow-up documents deliberately omit answers. Full worked
solutions, hints and teaching notes appear in the teacher document.

Suggested diagnostic time: 20 minutes. This is a short practice diagnostic,
not a TMUA mock, a complete syllabus assessment or a score predictor.

Resource page: https://maths.arijasad.com/algebra-to-tmua-diagnostic.html
